# Import libraries
#import RPi.GPIO as GPIO
import threading
from Piano_Output import listen_to_midi
import rtmidi
import mido #used ti reading midi file
from mido import MidiFile #midifile object
import MIDI_Read_V6 as myMIDI #my own midi reading py file
import tkinter.font as tkFont
from tkinter import * #gui
from functools import partial #pass function with variables
import pygame

NOTE_ON = 0x9
NOTE_OFF = 0x8
MIDI_PIANO_KEY_OFFSET = 21
BLACK_KEY = 0
WHITE_KEY = 1

#constant for pygame virtual piano
BLACK=(0,0,0)
WHITE=(255,255,255)
GREY=(200,200,200)
GREEN=(0,255,0)
BLUE=(0,0,255)
KEY_WIDTH = 19
HORIZONTAL_GAP = 2
BLACK_KEY_HEIGHT = 50
WHITE_KEY_HEIGHT = 100
BLACK_KEY_START_OFFSET = 9

white_key_pressed = [0] * 52
black_key_pressed = [0] * 50

def command_1():
    pass
   
#open midi file
def open_midi_file():
    global filename
    filename = filedialog.askopenfilename(initialdir="/home/pi/Documents/Andy Work/midis",title="Select a .mid file", filetypes=(("midi files","*.mid"),("all files","*.*")))
    file_box.insert(1.0,filename)
#     global led_array_time
#     global led_array
#     led_array_time, led_array = myMIDI.MIDI_Read(filename)
#     for item in led_array_time:
#         LED_Array_Time.append(item)
#     for item in led_array:
#         LED_Array.append(item)
def listen_to_midi():
    global is_playing_flag
    if is_playing_flag == 0:
        is_playing_flag = 1
        play_thread = threading.Thread(target=listen_to_midi_thread)
        play_thread.start()
#         play_thread.join()
    else:
        console_box.delete(1.0,END)
        console_box.insert(1.0, ("Currently playing: "+filename+"\n"))

#define the play function
def listen_to_midi_thread():
    global filename
    global midiout
    global midi_device
    global is_playing_flag
    global paint_queue
    global white_key_pressed
    global black_key_pressed
    global WHITE_KEY
    global BLACK_KEY
    global BLACK_KEY_ARRAY_INDEX
    try:
        console_box.delete(1.0,END)
        console_box.insert(1.0, ("Now playing: "+filename+"\n"))
        print(filename)
        current_midi=MidiFile(filename)
        for msg in current_midi.play():
            midiout.send_message(msg.bytes())
            c_Instruction = int((msg.bytes()[0] - msg.bytes()[0] % 0x10) /0x10)
            if c_Instruction==NOTE_ON or c_Instruction==NOTE_OFF:
                c_Note = msg.bytes()[1]
                c_Velocity = msg.bytes()[2]
                try:
                    key_loc = WHITE_KEY.index(c_Note)
                    if c_Instruction==NOTE_ON and c_Velocity>0: #if the key is pressed, draw green color //white_key_pressed //WHITE_KEY
                        white_key_pressed[key_loc] = 1
                    elif c_Instruction==NOTE_OFF or c_Velocity==0: #if the key is released, draw white color
                        white_key_pressed[key_loc] = 0
                except:
                    key_loc = BLACK_KEY.index(c_Note)
                    actual_key_loc = BLACK_KEY_ARRAY_INDEX[key_loc]
                    if c_Instruction==NOTE_ON and c_Velocity>0: #if the key is pressed, draw green color //white_key_pressed //WHITE_KEY
                        black_key_pressed[actual_key_loc] = 1
                    elif c_Instruction==NOTE_OFF or c_Velocity==0: #if the key is released, draw white color
                        black_key_pressed[actual_key_loc] = 0
        is_playing_flag = 0
        console_box.delete(1.0,END)
        console_box.insert(1.0, ("Finished!\n"))
    except:
        console_box.delete(1.0,END)
        console_box.insert(1.0, "Please select a file and a midi device before play!\n")
        console_box.insert(2.0, ("Current file: "+filename+"\n"))
        console_box.insert(3.0, "Current device: "+midi_device+"\n")

#refresh input device list
def refresh_input_list():
    global midiin
    global midiout
    midiin.close_port()
    midiout.close_port()
    myMenu_Input.delete(2,'end')
    port = 0;
    for device in midiin.get_ports():
        myMenu_Input.add_command(label=device, command=partial(open_port, device, port), font=menufont)
        port+=1
    device_box.delete(1.0,END)
    device_box.insert(1.0, ("Available MIDI devices updated! Select your MIDI device."))

#connect to midi device
def open_port(device, port):
    global midi_device
    global midiin
    global midiout
    midi_device = device
    midiin.close_port()
    midiout.close_port()
    midiin.open_port(port)
    midiout.open_port(port)
    listen_to_piano_thread = threading.Thread(target=listen_to_midi_input_thread)
    listen_to_piano_thread.start()
    device_box.delete(1.0,END)
    device_box.insert(1.0, (midi_device + " is connected!"))

#if the virtual piano is clicked, send the corresponding signal to the digital piano
def send_to_piano(note):
    global midiout
    try:
        msg = mido.Message.from_bytes([0x90, note, 0x60])
        midiout.send_message(msg.bytes())
    except:
        device_box.delete(1.0,END)
        device_box.insert(1.0, "No MIDI device detected! Connect and retry.")
    
#if a device is connected, this function should start as a thread to keep tracking of input message
def listen_to_midi_input_thread():
    global midiin
    global white_key_pressed
    global black_key_pressed
    while True:
        try:
            msg = midiin.get_message()
            if msg:
                c_Instruction = int((msg[0][0] - msg[0][0] % 0x10) /0x10)
                c_Note = msg[0][1]
                c_Velocity = msg[0][2]
#               here is the code which transfer the input to virtual piano gui:
                try:
                    key_loc = WHITE_KEY.index(c_Note)
                    if c_Instruction==NOTE_ON and c_Velocity>0: #if the key is pressed, draw green color //white_key_pressed //WHITE_KEY
                        white_key_pressed[key_loc] = 1
                    elif c_Instruction==NOTE_OFF or c_Velocity==0: #if the key is released, draw white color
                        white_key_pressed[key_loc] = 0
                except:
                    key_loc = BLACK_KEY.index(c_Note)
                    actual_key_loc = BLACK_KEY_ARRAY_INDEX[key_loc]
                    if c_Instruction==NOTE_ON and c_Velocity>0: #if the key is pressed, draw green color //white_key_pressed //WHITE_KEY
                        black_key_pressed[actual_key_loc] = 1
                    elif c_Instruction==NOTE_OFF or c_Velocity==0: #if the key is released, draw white color
                        black_key_pressed[actual_key_loc] = 0
        except:
            print("listen_to_midi_input_thread EXCEPTION")
# 
# #if a keypress is detected from the piano, then paint the color of the virtual piano GUI accordingly
# def paint_bg(key,state):
# #     pass
#     global WHITE_KEY
#     global BLACK_KEY
#     try:
#         key_num = WHITE_KEY.index(key+MIDI_PIANO_KEY_OFFSET)
#         if(key_num>=0):
# #             print("It's white key!")
#             if state==NOTE_ON:
#                 Button(white_key_frame, image=common_img, height=70, width=key_width, bg="lightgreen", command=partial(send_to_piano,WHITE_KEY[key_num])).grid(row=0,column=key_num)
#             elif state==NOTE_OFF:
#                 Button(white_key_frame, image=common_img, height=70, width=key_width, bg="white", command=partial(send_to_piano,WHITE_KEY[key_num])).grid(row=0,column=key_num)
#     except:
#         key_num = BLACK_KEY.index(key+MIDI_PIANO_KEY_OFFSET)
# #         print("It's black key!")
#         if state==NOTE_ON:
#             Button(black_key_frame, image=common_img, height=50, width=key_width, bg="lightgreen", command=partial(send_to_piano,BLACK_KEY[key_num])).grid(row=0,column=BLACK_KEY_ARRAY_INDEX[key_num])
#         elif state==NOTE_OFF:
#             Button(black_key_frame, image=common_img, height=50, width=key_width, bg="black", command=partial(send_to_piano,BLACK_KEY[key_num])).grid(row=0,column=BLACK_KEY_ARRAY_INDEX[key_num])

#this function will be launched as a thread at the start of the program to paint the GUI
# def paint_GUI():
#     global paint_queue
#     while True:
#         if not paint_queue.empty():
#             paint_item = paint_queue.get()
#             paint_bg(paint_item[0],paint_item[1])

#create a pygame virtual piano
def virtual_piano():
    global virtual_piano_screen
    is_running = True
    while is_running:
#         constantly looking for mouse press
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                is_running = False
            #if a key is pressed, make it green and send midi message to the piano
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = pygame.mouse.get_pos()
#                 print(mouse_x, mouse_y)
                if mouse_y > 50: #white key
                    white_key_num = int(mouse_x / KEY_WIDTH)
                    white_key_pressed[white_key_num] = 1
                    send_to_piano(WHITE_KEY[white_key_num])
                else:
                    black_key_num = int((mouse_x-BLACK_KEY_START_OFFSET) / KEY_WIDTH)
                    black_key_pressed[black_key_num] = 1
                    try:
                        actual_black_key_num = BLACK_KEY_ARRAY_INDEX.index(black_key_num)
                        send_to_piano(BLACK_KEY[actual_black_key_num])
                    except:
                        pass
                
            #if mouse release, clean all the pressed keys
            if event.type == pygame.MOUSEBUTTONUP:
                for i in range(0,52):
                    if white_key_pressed[i] == 1:
                        white_key_pressed[i] = 0
                for i in range(0,50):
                    if black_key_pressed[i] == 1:
                        black_key_pressed[i] = 0
                        
        virtual_piano_screen.fill(GREY)
        draw_piano()
        pygame.display.update()

#this function draw the pygame virtual piano
def draw_piano():
#     screen.blit()
    global virtual_piano_screen
    global BLACK_KEY_ARRAY_INDEX
    
    #draw white keys
    for i in range (0,52):
        if white_key_pressed[i] == 0:
            pygame.draw.rect(virtual_piano_screen,WHITE,(i*KEY_WIDTH, 0, KEY_WIDTH-HORIZONTAL_GAP, WHITE_KEY_HEIGHT)) #(topleft_x,topleft_y,x_length,y_length)
        elif white_key_pressed[i] == 1:
            pygame.draw.rect(virtual_piano_screen,GREEN,(i*KEY_WIDTH, 0, KEY_WIDTH-HORIZONTAL_GAP, WHITE_KEY_HEIGHT)) #(topleft_x,topleft_y,x_length,y_length)
        elif white_key_pressed[i] == 2:
            pygame.draw.rect(virtual_piano_screen,BLUE,(i*KEY_WIDTH, 0, KEY_WIDTH-HORIZONTAL_GAP, WHITE_KEY_HEIGHT)) #(topleft_x,topleft_y,x_length,y_length)
    #draw black keys
    for i in range (0,50):
        try:
            black_key_num = BLACK_KEY_ARRAY_INDEX.index(i)
            if black_key_num>=0:
#                 if black_key_pressed[i] == 0:
                pygame.draw.rect(virtual_piano_screen,BLACK,(i*KEY_WIDTH+BLACK_KEY_START_OFFSET, 0, KEY_WIDTH-HORIZONTAL_GAP, BLACK_KEY_HEIGHT)) #(topleft_x,topleft_y,x_length,y_length)
                if black_key_pressed[i] == 1:
                    pygame.draw.rect(virtual_piano_screen,GREEN,(i*KEY_WIDTH+BLACK_KEY_START_OFFSET+HORIZONTAL_GAP, 0, KEY_WIDTH-3*HORIZONTAL_GAP, BLACK_KEY_HEIGHT-HORIZONTAL_GAP)) #(topleft_x,topleft_y,x_length,y_length)
                elif black_key_pressed[i] == 2:
                    pygame.draw.rect(virtual_piano_screen,BLUE,(i*KEY_WIDTH+BLACK_KEY_START_OFFSET+HORIZONTAL_GAP, 0, KEY_WIDTH-2*HORIZONTAL_GAP, BLACK_KEY_HEIGHT-HORIZONTAL_GAP)) #(topleft_x,topleft_y,x_length,y_length)

        except:
            pass

#main
###############################################################################################################
#get available midi device
midiin = rtmidi.MidiIn()
midiout = rtmidi.MidiOut()
midi_device = ""
# available_ports_in = midiin.get_ports()
# available_ports_out = midiout.get_ports()
is_playing_flag = 0
filename = ''
LED_Array_Time = []
LED_Array = []
Current_Row_Playing = -1

WHITE_KEY = [21,23,
             24,26,28,
             29,31,33,35,
             36,38,40,
             41,43,45,47,
             48,50,52,
             53,55,57,59,
             60,62,64,
             65,67,69,71,
             72,74,76,
             77,79,81,83,
             84,86,88,
             89,91,93,95,
             96,98,100,
             101,103,105,107,
             108]

BLACK_KEY = [22,
             25,27,
             30,32,34,
             37,39,
             42,44,46,
             49,51,
             54,56,58,
             61,63,
             66,68,70,
             73,75,
             78,80,82,
             85,87,
             90,92,94,
             97,99,
             102,104,106]


BLACK_KEY_ARRAY_INDEX = [0,
                         2,3,
                         5,6,7,
                         9,10,
                         12,13,14,
                         16,17,
                         19,20,21,
                         23,24,
                         26,27,28,
                         30,31,
                         33,34,35,
                         37,38,
                         40,41,42,
                         44,45,
                         47,48,49]
                         
# print(available_ports)


###############################################################################################################
#create root frame
root = Tk()
root.title('Digital Piano Fingering Guide')
root.geometry("1024x260")

###############################################################################################################
#create menu and attach to the top

# select font style
menufont = tkFont.Font(size=20)
textfont = tkFont.Font(size=15)
#create menu attach to the root
myMenu = Menu(root) #create root menu attach to the root
root.config(menu=myMenu)
#create "File" menu
myMenu_File = Menu(myMenu) #create file menu attach to the root menu
myMenu.add_cascade(label=" File ", menu=myMenu_File, font=menufont)
myMenu_File.add_command(label="New...", command=command_1, font=menufont)
myMenu_File.add_command(label="Open", command=open_midi_file, font=menufont)
myMenu_File.add_separator()
myMenu_File.add_command(label="Exit", command=root.destroy, font=menufont)

#create "Input" menu. This menu will dynamically detect new input midi devices
myMenu_Input= Menu(myMenu) #create file menu attach to the root menu    
myMenu.add_cascade(label=" Input ", menu=myMenu_Input, font=menufont)
myMenu_Input.add_command(label="Refresh", command=refresh_input_list, font=menufont)
   
#create "Setting" menu
myMenu_Setting = Menu(myMenu) #create file menu attach to the root menu
myMenu.add_cascade(label=" Setting ", menu=myMenu_Setting, font=menufont)
myMenu_Setting.add_command(label="Tempo", command=command_1, font=menufont)
myMenu_Setting.add_command(label="Brightness", command=command_1, font=menufont)

###############################################################################################################
#create a device frame for connect midi device
# device_frame = Frame(root)
# device_frame.grid(row=0,column=1)
widget_frame = Frame(root)
widget_frame.grid(row=0,column=0)

device_button = Button(widget_frame, text="Connect",font=menufont)
device_button.grid(row=0,column=0)

device_box = Text(widget_frame, width=40, height=1,font=textfont)
device_box.insert(1.0, "Please connect your MIDI piano via USB cable.")
device_box.grid(row=0,column=1)

#create a text box for open file
# file_frame = Frame(root)
# file_frame.grid(row=2,column=1)

file_button = Button(widget_frame, text="File", width=10, height=1, font=menufont, command=open_midi_file)
file_button.grid(row=1,column=0)

file_box = Text(widget_frame, width=40, height=1,font=textfont)
file_box.insert(1.0, "Please select the midi file you want to play.")
file_box.grid(row=1,column=1)

#create a text box for diagnostic
console_box = Text(widget_frame, width=40, height=5, font=textfont)# width=60, height=20
console_box.grid(row=2,column=1)

#play mode selection
text_button_frame = Frame(root)
text_button_frame.grid(row=1,column=0)

play_button = Button(text_button_frame, text="Listen!", command=listen_to_midi, font=menufont)
play_button.grid(row=0,column=0)

###############################################################################################################
#create virtual piano
pygame.init()
#create the screen, title and icon
virtual_piano_screen = pygame.display.set_mode((986,100))
pygame.display.set_caption('Digital Piano Fingering Guide')
my_virtual_piano = threading.Thread(target=virtual_piano)
my_virtual_piano.start()

###############################################################################################################
#run the GUI loop
root.mainloop()
