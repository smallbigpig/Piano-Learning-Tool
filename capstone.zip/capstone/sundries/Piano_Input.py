import mido #read midi file
import rtmidi #communication with piano
from tkinter import filedialog #gui select song
from mido import MidiFile

#get available midi device
midiin = rtmidi.MidiIn()
available_ports = midiin.get_ports()
print(available_ports)

#connect the first detected midi device
if len(available_ports)>=2:
    midiin.open_port(1)
else:
    print("Please connect a MIDI keyboard and try again!")

while 1:
    message = midiin.get_message()
    if message:
        print(message)