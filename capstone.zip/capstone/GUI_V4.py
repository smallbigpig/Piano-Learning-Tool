
import pygame

#define some colors  #R,G,B
BLACK=(0,0,0)
WHITE=(255,255,255)
GREY=(200,200,200)
GREEN=(0,255,0)

KEY_WIDTH = 19
HORIZONTAL_GAP = 2
BLACK_KEY_HEIGHT = 50
WHITE_KEY_HEIGHT = 100
BLACK_KEY_START_OFFSET = 9

#this function draw the piano
def draw_piano():
#     screen.blit()
    global screen
    global BLACK_KEY_ARRAY_INDEX
    
    #draw white keys
    for i in range (0,52):
        if white_key_pressed[i] == 0:
            pygame.draw.rect(screen,WHITE,(i*KEY_WIDTH, 0, KEY_WIDTH-HORIZONTAL_GAP, WHITE_KEY_HEIGHT)) #(topleft_x,topleft_y,x_length,y_length)
        elif white_key_pressed[i] == 1:
            pygame.draw.rect(screen,GREEN,(i*KEY_WIDTH, 0, KEY_WIDTH-HORIZONTAL_GAP, WHITE_KEY_HEIGHT)) #(topleft_x,topleft_y,x_length,y_length)

    #draw black keys
    for i in range (0,50):
        try:
            black_key_num = BLACK_KEY_ARRAY_INDEX.index(i)
            if black_key_num>=0:
                if black_key_pressed[i] == 0:
                    pygame.draw.rect(screen,BLACK,(i*KEY_WIDTH+BLACK_KEY_START_OFFSET, 0, KEY_WIDTH-HORIZONTAL_GAP, BLACK_KEY_HEIGHT)) #(topleft_x,topleft_y,x_length,y_length)
                elif black_key_pressed[i] == 1:
                    pygame.draw.rect(screen,GREEN,(i*KEY_WIDTH+BLACK_KEY_START_OFFSET, 0, KEY_WIDTH-HORIZONTAL_GAP, BLACK_KEY_HEIGHT)) #(topleft_x,topleft_y,x_length,y_length)
        except:
            pass

BLACK_KEY_ARRAY_INDEX = [0,
                         2,3,
                         5,6,7,
                         9,10,
                         12,13,14,
                         16,17,
                         19,20,21,
                         23,24,
                         26,27,28,
                         30,31,
                         33,34,35,
                         37,38,
                         40,41,42,
                         44,45,
                         47,48,49]

white_key_pressed = [0] * 52
black_key_pressed = [0] * 50

###############################################################################################################
#main program
pygame.init()

#create the screen, title and icon
screen = pygame.display.set_mode((986,100))
pygame.display.set_caption('Digital Piano Fingering Guide')
# icon = pygame.image.load('piano.png')
# pygame.display.set_icon(icon)

is_running = True

while is_running:
    
#     mouse_x, mouse_y = pygame.mouse.get_pos()
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            is_running = False
        
        #if a key is pressed, make it green and send midi message to the piano
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            print(mouse_x, mouse_y)
            if mouse_y > 50: #white key
                white_key_num = int(mouse_x / KEY_WIDTH)
                white_key_pressed[white_key_num] = 1
            else:
                black_key_num = int((mouse_x-BLACK_KEY_START_OFFSET) / KEY_WIDTH)
                black_key_pressed[black_key_num] = 1
                
        #if mouse release, clean all the pressed keys
        if event.type == pygame.MOUSEBUTTONUP:
            for i in range(0,52):
                if white_key_pressed[i] == 1:
                    white_key_pressed[i] = 0
            for i in range(0,50):
                if black_key_pressed[i] == 1:
                    black_key_pressed[i] = 0         
            
    screen.fill(GREY)
    draw_piano()
    
    pygame.display.update()






