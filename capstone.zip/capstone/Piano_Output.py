import mido #read midi file
import rtmidi #communication with piano
from tkinter import filedialog #gui select song
from mido import MidiFile
import time

def listen_to_midi():
    #get available midi device
    midiout = rtmidi.MidiOut()
    available_ports = midiout.get_ports()
    print(available_ports)

    #connect the first detected midi device
    if len(available_ports)>=2:
        midiout.open_port(1)
    else:
        midiout.open_virtual_port("My virtual output")

    #open a midi file to play
    filename = filedialog.askopenfilename(initialdir="/home/pi/Documents/Andy Work/midis",title="Select a .mid file", filetypes=(("midi files","*.mid"),("all files","*.*")))
    print(filename)
    current_MIDI = MidiFile(filename)
    
#     Merged_Track = mido.merge_tracks(current_MIDI.tracks)
#     midi_array = []
#     for msg in Merged_Track:
# #         if not msg.is_meta and len(msg.bytes())==3 and (msg.bytes()[0] == 144 or msg.bytes()[0] == 128):
#         midi_array.append(msg)
#     
#     current_position = 0
#     while True:
#         try:
#             msg = midi_array[current_position]
#             midiout.send_message(msg.bytes())
#             delay = msg.time/2000
#             time.sleep(delay)
#         except:
#             pass
#         current_position+=1
        
#     #play the midi file
#     for msg in current_MIDI.play():
#         midiout.send_message(msg.bytes())
#         print(msg.bytes())

# listen_to_midi()