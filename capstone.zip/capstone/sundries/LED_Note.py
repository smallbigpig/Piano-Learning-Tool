class LED_Note:
    Note = 0
    Channel = 0
    def __init__(self):
        self.Note = 0
        self.Channel = 0
        
    def __init__(self,Note,Channel):
        self.Note = Note
        self.Channel = Channel
    
    def set_Note(self,Note):
        self.Note = Note
    
    def set_Channel(self,Channel):
        self.Channel = Channel
        
    def Print(self):
        print("Note:",self.Note, end=" ")
        print("Channel:",self.Channel, end=" ")

note1 = LED_Note(49,3)
note2 = LED_Note(50,2)
notes = [note1, note2]
for n in notes:
    n.Print()
    print("")

note3 = LED_Note(49,3)
notes.remove(note3)
for n in notes:
    n.Print()
    print("")