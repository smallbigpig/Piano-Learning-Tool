import mido #read midi file
import rtmidi #communication with piano
from tkinter import filedialog #gui select song
from mido import MidiFile

#get available midi device
midiout = rtmidi.MidiOut()
available_ports = midiout.get_ports()
print(available_ports)

#connect the first detected midi device
if len(available_ports)>=2:
    midiout.open_port(1)
else:
    midiout.open_virtual_port("My virtual output")

#open a midi file to play
filename = filedialog.askopenfilename(initialdir="/home/pi/Documents/Andy Work/midis",title="Select a .mid file", filetypes=(("midi files","*.mid"),("all files","*.*")))
current_MIDI = MidiFile(filename)

#play the midi file
for msg in current_MIDI.play():
    midiout.send_message(msg.bytes())