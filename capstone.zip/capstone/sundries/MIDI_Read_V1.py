from tkinter import filedialog
from mido import MidiFile
import mido

#open midi file
filename = filedialog.askopenfilename(initialdir="/home/pi/Documents/Andy Work/midis",title="Select a .mid file", filetypes=(("midi files","*.mid"),("all files","*.*")))

#read midi file
current_MIDI = MidiFile(filename)

#for i, track in enumerate(current_MIDI.tracks):
#    print('Track {}:{}'.format(i,track.name))
#    for msg in track:
#        print(msg)

#merge all tracks
#new_Merged_Track = mido.merge_tracks(current_MIDI.tracks)
#for msg in new_Merged_Track:
#    if not msg.is_meta:
#        print(msg)

#print(current_MIDI.filename)
#print(current_MIDI.type)
#print(current_MIDI.ticks_per_beat)
#print(current_MIDI.charset)
#print(current_MIDI.debug)
#print(current_MIDI.clip)
#print(current_MIDI.length) #playback time in second

#print(current_MIDI.tracks[1])
#for message in current_MIDI.tracks[1]:
#    print(message.type)#if note_on  or note_off, then function note

#for message in current_MIDI.tracks[1]:
#    if not message.is_meta:
#        print(message.time)#delta time of each action

#for message in current_MIDI.tracks[1]:
#    if not message.is_meta:
#        print(message.bytes())#3 bytes message

for message in current_MIDI.tracks[1]:
    if not message.is_meta:
#         print(message.hex(),message.time)#3 bytes message
        print(message)#3 bytes message

        
