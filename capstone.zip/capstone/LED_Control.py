#IMPORTANT!!!: This must be lunch in sudo mode!
#sudo python file_name

from rpi_ws281x import PixelStrip, Color
import time
from random import randrange

#left
L_LED_COUNT = 12*9
L_LED_PIN = 13
L_LED_FREQ_HZ = 800000
L_LED_DMA = 10
L_LED_BRIGHTNESS = 1
L_LED_INVERT = False
L_LED_CHANNEL = 1

#right
R_LED_COUNT = 9*12
R_LED_PIN = 18
R_LED_FREQ_HZ = 800000
R_LED_DMA = 10
R_LED_BRIGHTNESS = 1
R_LED_INVERT = False
R_LED_CHANNEL = 0

l_strip = PixelStrip(L_LED_COUNT, L_LED_PIN, L_LED_FREQ_HZ, L_LED_DMA, L_LED_INVERT, L_LED_BRIGHTNESS, L_LED_CHANNEL)
r_strip = PixelStrip(R_LED_COUNT, R_LED_PIN, R_LED_FREQ_HZ, R_LED_DMA, R_LED_INVERT, R_LED_BRIGHTNESS, R_LED_CHANNEL)
l_strip.begin()
r_strip.begin()


for x in range(0, L_LED_COUNT):
    l_strip.setPixelColor(x, Color(randrange(0,255),randrange(0,255),randrange(0,255)))
for y in range(0, R_LED_COUNT):
    r_strip.setPixelColor(y, Color(randrange(0,255),randrange(0,255),randrange(0,255)))

l_strip.show()
r_strip.show()
time.sleep(0.05)

# def led_panel_update():
#     global led_panel
#     #update left panel
#     current_led = 0
#     load_direction = True
    #update 0-47 key
#     for i in range(0,48):
#         #update 9 led for each key
#         for j in range(0,9):
#             if load_direction:
#                 color = led_panel[8-j][47-i]
#                 if color == 1:
#                     l_strip.setPixelColor(current_led, Color(255,255,255))
#             else:
#                 color = led_panel[j][47-i]
#                 if color == 1:
#                     l_strip.setPixelColor(current_led, Color(255,255,255))
#             current_led = current_led + 1
#         load_direction = not load_direction
        
#     #update right panel
#     current_led = 0
#     load_direction = True
#     #update 0-47 key
#     for i in range(48,89):
#         #update 9 led for each key
#         for j in range(0,9):
#             if load_direction:
#                 color = led_panel[8-j][i]
#                 if color == 1:
#                     l_strip.setPixelColor(current_led, Color(255,255,255))
#             else:
#                 color = led_panel[j][i]
#                 if color == 1:
#                     l_strip.setPixelColor(current_led, Color(255,255,255))
#             current_led = current_led + 1
#         load_direction = not load_direction