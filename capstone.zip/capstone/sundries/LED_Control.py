#IMPORTANT!!!: This must be lunch in sudo mode!
#sudo python file_name

from rpi_ws281x import PixelStrip, Color
import time
import random

#left
L_LED_COUNT = 144 #eventually will be 88 * 12
L_LED_PIN = 13
L_LED_FREQ_HZ = 800000
L_LED_DMA = 10
L_LED_BRIGHTNESS = 1
L_LED_INVERT = False
L_LED_CHANNEL = 1

#right
R_LED_COUNT = 144 #eventually will be 88 * 12
R_LED_PIN = 19
R_LED_FREQ_HZ = 800000
R_LED_DMA = 10
R_LED_BRIGHTNESS = 1
R_LED_INVERT = False
R_LED_CHANNEL = 1

l_strip = PixelStrip(L_LED_COUNT, L_LED_PIN, L_LED_FREQ_HZ, L_LED_DMA, L_LED_INVERT, L_LED_BRIGHTNESS, L_LED_CHANNEL)
r_strip = PixelStrip(R_LED_COUNT, R_LED_PIN, R_LED_FREQ_HZ, R_LED_DMA, R_LED_INVERT, R_LED_BRIGHTNESS, R_LED_CHANNEL)
l_strip.begin()
r_strip.begin()


for x in range(0, L_LED_COUNT):
    for y in range(0, L_LED_COUNT):
        if x==y:
            l_strip.setPixelColor(y, Color(255,255,255))
            r_strip.setPixelColor(y, Color(255,255,255))
        else:
            l_strip.setPixelColor(y, Color(0,0,0))
            r_strip.setPixelColor(y, Color(0,0,0))
    l_strip.show()
    r_strip.show()
    time.sleep(0.05)
    
# for x in range(0, L_LED_COUNT):
#     l_strip.setPixelColor(x, Color(255,255,255))
# #     l_strip.setPixelColor(x, Color(random.randrange(0,256),random.randrange(0,256),random.randrange(0,256)))
# #     r_strip.setPixelColor(x, Color(random.randrange(0,256),random.randrange(0,256),random.randrange(0,256)))
# l_strip.show()
# 
# for x in range(0, R_LED_COUNT):
#     r_strip.setPixelColor(x, Color(255,255,255))
# #     l_strip.setPixelColor(x, Color(random.randrange(0,256),random.randrange(0,256),random.randrange(0,256)))
# #     r_strip.setPixelColor(x, Color(random.randrange(0,256),random.randrange(0,256),random.randrange(0,256)))
# r_strip.show()
                        