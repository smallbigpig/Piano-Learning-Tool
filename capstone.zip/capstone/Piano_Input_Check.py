import mido #read midi file
import rtmidi #communication with piano
from tkinter import filedialog #gui select song
from mido import MidiFile

NOTE_ON = 0x9
NOTE_OFF = 0x8
MIDI_PIANO_KEY_OFFSET = 21
NUM_OF_KEY = 88

current_Pressed_Keys = []

def print_Pressed_Keys(current_Pressed_Keys):
    list_of_key = []
    for i in range(0,len(current_Pressed_Keys)):
        if current_Pressed_Keys[i] == 1:
            list_of_key.append(i)
    print(list_of_key)

#main
    #initialize pressed key list
for i in range(0,NUM_OF_KEY):
    current_Pressed_Keys.append(0)
print(current_Pressed_Keys)

#get available midi device
midiin = rtmidi.MidiIn()
available_ports = midiin.get_ports()
print(available_ports)

#connect the first detected midi device
if len(available_ports)>=2:
    midiin.open_port(1)
else:
    print("Please connect a MIDI keyboard and try again!")

while 1:
    message = midiin.get_message()
    if message:
        print(message[0])
        c_Instruction = int((message[0][0] - message[0][0] % 0x10) /0x10)
        c_Note = message[0][1] - MIDI_PIANO_KEY_OFFSET
        c_Velocity = message[0][2]
#         print(c_Instruction,c_Note,c_Velocity)
        if c_Instruction==NOTE_ON and c_Velocity>0:
            current_Pressed_Keys[c_Note] = 1
        elif c_Instruction==NOTE_OFF or c_Velocity==0:
            current_Pressed_Keys[c_Note] = 0
#         print_Pressed_Keys(current_Pressed_Keys)
#         print(current_Pressed_Keys)
        
        
