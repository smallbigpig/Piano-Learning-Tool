from tkinter import filedialog
from mido import MidiFile
import mido 

#constants:
ROWS_OF_LED = 10
NUM_OF_KEY = 88
NOTE_ON = 0x9
NOTE_OFF = 0x8
LED_ARRAY_ALL_NOTE = 0
LED_ARRAY_ALL_CHANNEL = 1
LED_ARRAY_ALL_START = 2
LED_ARRAY_ALL_STOP = 3
LED_ARRAY_ALL_DURATION = 4
    
#data format
#cell of LED_Array_All: [Note,Channel,Start_Time]

#check if and item is in a list
def Is_In_List(item, List):
    result = False
    for msg in List:
        if item == msg:
            result = True
            break
    return result

#add an item to the list
def Add_To_List(item, List):
    if not Is_In_List(item, List):
        List.append(item)
        
#remove an item from the list
def Remove_From_List(item, List):
    if Is_In_List(item, List):
        List.remove(item)

#check if a channel is muted
def Channel_Is_Muted(channel, Muted_Channel_List):
    return Is_In_List(channel, Muted_Channel_List)

#mute a channel
def Mute_Channel(channel, Muted_Channel_List):
    Add_To_List(channel, Muted_Channel_List)
    
#unmute a channel
def Unmute_Channel(channel, Muted_Channel_List):
    Remove_From_List(channel, Muted_Channel_List)
  
#function to sort the led array
def Sort_LED_Array_All(array):
    for subarray in array:
        Sort_LED_Array_Sub(subarray)

#function to sort the note from low to high
def Sort_LED_Array_Sub(array):
    temp_array = []
    length = len(array)
    for i in range(0,length-1):
        largest = array[0][:]
        for j in range(1,length-i):
            if array[j][0] > largest[0]:
                largest = array[j][:]
        temp_array.append(largest)
        array.remove(largest)
    for i in range(0,length-1):
        array.append(temp_array.pop())


#main starts here: 
def MIDI_Read(filename):
    #open midi file
#     filename = filedialog.askopenfilename(initialdir="/home/pi/Documents/Andy Work/midis",title="Select a .mid file", filetypes=(("midi files","*.mid"),("all files","*.*")))

    #read midi file
    current_MIDI = MidiFile(filename)
#     print(filename)

    #merge all tracks
    new_Merged_Track = mido.merge_tracks(current_MIDI.tracks)

    #variables
    length_of_MIDI = 0

    #88xROWS_OF_LED int matrix used to write to LED strip
    #LED_Array_Strip = [list(range(0,NUM_OF_KEY)) for i in range(ROWS_OF_LED)]

    #lists contains various midi data
    l_Instruction = []
    l_Channel = []
    l_Note = []
    l_Velocity = []
    l_Time = []

    #list of channel which is muted
    Muted_Channel_List = []

    #Mute channel 9
    Mute_Channel(9,Muted_Channel_List)

    #list which contains translated LED info
    LED_Array_All = []
    LED_Array_Time = []

    #list which represent the current LED array
    LED_Array_Current = []

    #get data from midi file
    for message in new_Merged_Track:
        if not message.is_meta and len(message.bytes())==3:
            #extract information from the byte
            c_Instruction = int((message.bytes()[0] - message.bytes()[0] % 0x10) /0x10)
            c_Channel = message.bytes()[0] % 0x10
            c_Note = message.bytes()[1]
            c_Velocity = message.bytes()[2]
            c_Time = message.time
            if c_Instruction == NOTE_ON or c_Instruction == NOTE_OFF:
                if not Channel_Is_Muted(c_Channel,Muted_Channel_List):
                    l_Instruction.append(c_Instruction)
                    l_Channel.append(c_Channel)
                    l_Note.append(c_Note)
                    l_Velocity.append(c_Velocity)
                    l_Time.append(c_Time)
                    length_of_MIDI+=1
#         #for testing purpose, only 200 samples is selected from the track
#         if length_of_MIDI > 100:
#             break

    #translate midi input to LED output in form of a 2d array
    i = 0
    start_time_in_ms = 0
    stop_time_in_ms = 0
    while i < length_of_MIDI:
        # If the instruction is to release a note, we know that a node is about to finish and it's time to refresh the current LED positions to the LED array
        stop_time_in_ms += l_Time[i]
        if l_Instruction[i] == NOTE_OFF or l_Velocity[i] == 0:
            #Remove(turn off) ith LED form the current list
            Remove_From_List([l_Note[i],l_Channel[i]],LED_Array_Current)
        #else, a new key is pressed and should be add to current LED array
        elif l_Instruction[i] == NOTE_ON and l_Velocity[i] > 0:
            #Remove(turn off) ith LED form the current list
            Add_To_List([l_Note[i],l_Channel[i]],LED_Array_Current)
            #check if the following note time is 0, which means they are played at the same time
            i += 1
            if i < length_of_MIDI:
                while l_Time[i] == 0:
                    Add_To_List([l_Note[i],l_Channel[i]],LED_Array_Current)
                    i += 1
            i += -1
            #add the current led list to the entire list
            LED_Array_All.append(LED_Array_Current[:])
            LED_Array_Time.append([start_time_in_ms,stop_time_in_ms,stop_time_in_ms-start_time_in_ms])
            start_time_in_ms = stop_time_in_ms
        i += 1

#     #print out: [operation, channel, note, velocity, time]
#     for i in range (0,length_of_MIDI-1):
#     #    if not Channel_Is_Muted(l_Channel[i], Muted_Channel_List):
#         print(l_Instruction[i],l_Channel[i],l_Note[i],l_Velocity[i],l_Time[i])

    #sort the notes in a low to high order
    Sort_LED_Array_All(LED_Array_All)

#     #print Time[start,stop,duration] LED_ARRAY_ALL[notes, channels], filter out hidden channels
#     for i in range(0,len(LED_Array_All)-1):
#         print("Time[start,stop,duration]:",LED_Array_Time[i],end=" Notes[position,channel]:")
#         for j in range(0,len(LED_Array_All[i])):
#             if not Channel_Is_Muted(LED_Array_All[i][j][LED_ARRAY_ALL_CHANNEL],Muted_Channel_List):
#                 print(LED_Array_All[i][j], end=" ")
#         print("")
    
    return LED_Array_Time, LED_Array_All



