# Import libraries
#import RPi.GPIO as GPIO
from tkinter import filedialog #gui select song
import threading
import rtmidi
import mido #used ti reading midi file
from mido import MidiFile #midifile object
import tkinter.font as tkFont
from tkinter import * #gui
from functools import partial #pass function with variables
import pygame
import time

NOTE_ON = 0x9
NOTE_OFF = 0x8
MIDI_PIANO_KEY_OFFSET = 21
BLACK_KEY = 0
WHITE_KEY = 1

#constant for pygame virtual piano
BLACK=(0,0,0)
WHITE=(255,255,255)
GREY=(200,200,200)
DARK_GREY=(150,150,150)
RED=(255,100,100)
GREEN=(100,255,100)
BLUE=(100,100,255)
KEY_WIDTH = 19
HORIZONTAL_GAP = 2
BLACK_KEY_HEIGHT = 50
WHITE_KEY_HEIGHT = 100
BLACK_KEY_START_OFFSET = 9

#these 2 arrays are used to paint the GUI
midi_white_key_pressed = [0] * 52
midi_black_key_pressed = [0] * 50
user_white_key_pressed = [0] * 52
user_black_key_pressed = [0] * 50

#this times the time interval will accelerate/deaccelerate the speed of the song while play with midi
tempo_multiplier = 0.5

#quit flag will rise and force any playing thread to quit once the user pressed "Stop" button
quit_flag = 0

#these are the parameters used to identify the current position of playing, the loop start and loop end
max_end = 0
current_position = 0
loop_start = 0
loop_end = 0

def command_1():
    pass

#this mapping function is used to allocate the position of the playing note on the GUI
def map_range_to_range(value, from_range_min, from_range_max, to_range_min, to_range_max):
    if value == from_range_min:
        result = to_range_min
    elif value == from_range_max:
        result = to_range_max
    else:
        result = (to_range_max+to_range_min*(from_range_max-value)/(value-from_range_min))/(1+(from_range_max-value)/(value-from_range_min))
    return int(result)

#if the quit button is pressed, this function will rise the quit flag which terminate the playing thread
def stop_play():
    global quit_flag
    global is_playing_flag
    if is_playing_flag==1:
        quit_flag = 1
        
#open midi file
def open_midi_file():
    global filename
    filename = filedialog.askopenfilename(initialdir="/home/pi/Documents/Andy Work/midis",title="Select a .mid file", filetypes=(("midi files","*.mid"),("all files","*.*")))
    file_box.insert(1.0,filename)
#     global led_array_time
#     global led_array
#     led_array_time, led_array = myMIDI.MIDI_Read(filename)
#     for item in led_array_time:
#         LED_Array_Time.append(item)
#     for item in led_array:
#         LED_Array.append(item)

#this is the function that will be called when the "Play" button is pressed. it will create a thread that play the song and wait for user input. If a thread is already created, it will do nothing
def play_with_midi():
    global is_playing_flag
    if is_playing_flag == 0:
        is_playing_flag = 1
        play_thread = threading.Thread(target=play_with_midi_thread)
        play_thread.start()
#         play_thread.join()
    else:
        console_box.delete(1.0,END)
        console_box.insert(1.0, ("Currently playing: "+filename+"\n"))

#define the listen function
def play_with_midi_thread():
    global filename
    global midiout
    global midi_device
    global is_playing_flag
    global paint_queue
    global midi_white_key_pressed
    global midi_black_key_pressed
    global user_white_key_pressed
    global user_black_key_pressed
    global WHITE_KEY
    global BLACK_KEY
    global BLACK_KEY_ARRAY_INDEX
    global tempo_multiplier
    global MIDI_PIANO_KEY_OFFSET
    global quit_flag
    global max_end
    global current_position
    global loop_start
    global loop_end
    try:
        console_box.delete(1.0,END)
        console_box.insert(1.0, ("Now playing: "+filename+"\n"))
        current_midi=MidiFile(filename)
        Merged_Track = mido.merge_tracks(current_midi.tracks)
        midi_array = []
        for msg in Merged_Track:
            if not msg.is_meta and len(msg.bytes())==3 and (msg.bytes()[0] == 144 or msg.bytes()[0] == 128):
#store the message for fast forward and backward
                midi_array.append(msg)
#initialize loop position
        loop_start = 0
        loop_end = 20
#play in the loop until quit flag is raised
        current_position = 0
        while quit_flag==0:
#load the current message
            msg = midi_array[current_position]
#             midiout.send_message(msg.bytes())
            delay = msg.time/1000*tempo_multiplier
#if a new key or a set of new key is pressed, wait for user input
            if delay>0:
                while(midi_white_key_pressed!=user_white_key_pressed or midi_black_key_pressed!=user_black_key_pressed):
                    if quit_flag==1:
                        break
            time.sleep(delay)
#update the GUI
            c_Instruction = int((msg.bytes()[0] - msg.bytes()[0] % 0x10) /0x10)
            c_Note = msg.bytes()[1]
            c_Velocity = msg.bytes()[2]  
            try:
                key_loc = WHITE_KEY.index(c_Note)
                if c_Instruction==NOTE_ON and c_Velocity>0: #if the key is pressed, draw green color //white_key_pressed //WHITE_KEY
                    midi_white_key_pressed[key_loc] = 1
                elif c_Instruction==NOTE_OFF or c_Velocity==0: #if the key is released, draw white color
                    midi_white_key_pressed[key_loc] = 0
            except:
                key_loc = BLACK_KEY.index(c_Note)
                actual_key_loc = BLACK_KEY_ARRAY_INDEX[key_loc]
                if c_Instruction==NOTE_ON and c_Velocity>0: #if the key is pressed, draw green color //white_key_pressed //WHITE_KEY
                    midi_black_key_pressed[actual_key_loc] = 1
                elif c_Instruction==NOTE_OFF or c_Velocity==0: #if the key is released, draw white color
                    midi_black_key_pressed[actual_key_loc] = 0
# progress to the next message
            current_position+=1
#if reach the end of file, loop
            if current_position >= loop_end:
                current_position = loop_start
        
        quit_flag = 0
        is_playing_flag = 0
        clear_GUI()
        console_box.delete(1.0,END)
        console_box.insert(1.0, ("Finished!\n"))
    except:
        quit_flag = 0
        is_playing_flag = 0
        console_box.delete(1.0,END)
        console_box.insert(1.0, "Please select a file and a midi device before play!\n")
        console_box.insert(2.0, ("Current file: "+filename+"\n"))
        console_box.insert(3.0, "Current device: "+midi_device+"\n")


#this is the function that will be called when the "Listen" button is pressed. it will create a thread that play the song. If a thread is already created, it will do nothing
def listen_to_midi():
    global is_playing_flag
    if is_playing_flag == 0:
        is_playing_flag = 1
        play_thread = threading.Thread(target=listen_to_midi_thread)
        play_thread.start()
#         play_thread.join()
    else:
        console_box.delete(1.0,END)
        console_box.insert(1.0, ("Currently listening: "+filename+"\n"))

# #define the listen function v1
# def listen_to_midi_thread():
#     global filename
#     global midiout
#     global midi_device
#     global is_playing_flag
#     global paint_queue
#     global midi_white_key_pressed
#     global midi_black_key_pressed
#     global WHITE_KEY
#     global BLACK_KEY
#     global BLACK_KEY_ARRAY_INDEX
#     global quit_flag
#     global max_end
#     global current_position
#     global loop_start
#     global loop_end
#     try:
#         console_box.delete(1.0,END)
#         console_box.insert(1.0, ("Now playing: "+filename+"\n"))
#         current_midi=MidiFile(filename)
#         Merged_Track = mido.merge_tracks(current_midi.tracks)
#         midi_array = []
#         for msg in Merged_Track:
#             if not msg.is_meta and len(msg.bytes())==3 and (msg.bytes()[0] == 144 or msg.bytes()[0] == 128):
# #store the message for fast forward and backward
#                 midi_array.append(msg)
# #initialize loop position
#         max_end = len(midi_array)
#         loop_start = 0
#         loop_end = max_end
# #play in the loop until quit flag is raised
#         current_position = 0
#         while quit_flag==0:
# #load the current message
#             msg = midi_array[current_position]
#             midiout.send_message(msg.bytes())
#             delay = msg.time/1000*tempo_multiplier
#             time.sleep(delay)
# #update the GUI
#             c_Instruction = int((msg.bytes()[0] - msg.bytes()[0] % 0x10) /0x10)
#             c_Note = msg.bytes()[1]
#             c_Velocity = msg.bytes()[2]  
#             try:
#                 key_loc = WHITE_KEY.index(c_Note)
#                 if c_Instruction==NOTE_ON and c_Velocity>0: #if the key is pressed, draw green color //white_key_pressed //WHITE_KEY
#                     midi_white_key_pressed[key_loc] = 1
#                 elif c_Instruction==NOTE_OFF or c_Velocity==0: #if the key is released, draw white color
#                     midi_white_key_pressed[key_loc] = 0
#             except:
#                 key_loc = BLACK_KEY.index(c_Note)
#                 actual_key_loc = BLACK_KEY_ARRAY_INDEX[key_loc]
#                 if c_Instruction==NOTE_ON and c_Velocity>0: #if the key is pressed, draw green color //white_key_pressed //WHITE_KEY
#                     midi_black_key_pressed[actual_key_loc] = 1
#                 elif c_Instruction==NOTE_OFF or c_Velocity==0: #if the key is released, draw white color
#                     midi_black_key_pressed[actual_key_loc] = 0
# # progress to the next message
#             current_position+=1
#             if current_position >= max_end:
#                 current_position = loop_start
#         
#         quit_flag = 0
#         is_playing_flag = 0
#         clear_GUI()
#         console_box.delete(1.0,END)
#         console_box.insert(1.0, ("Finished!\n"))
#     except:
#         quit_flag = 0
#         is_playing_flag = 0
#         console_box.delete(1.0,END)
#         console_box.insert(1.0, "Please select a file and a midi device before play!\n")
#         console_box.insert(2.0, ("Current file: "+filename+"\n"))
#         console_box.insert(3.0, "Current device: "+midi_device+"\n")

#define the listen function v2
def listen_to_midi_thread():
    global filename
    global midiout
    global midi_device
    global is_playing_flag
    global paint_queue
    global midi_white_key_pressed
    global midi_black_key_pressed
    global WHITE_KEY
    global BLACK_KEY
    global BLACK_KEY_ARRAY_INDEX
    global quit_flag
    global max_end
    global current_position
    global loop_start
    global loop_end
    try:
        console_box.delete(1.0,END)
        console_box.insert(1.0, ("Now playing: "+filename+"\n"))
        current_midi=MidiFile(filename)
        Merged_Track = mido.merge_tracks(current_midi.tracks)
        midi_array = []
        for msg in Merged_Track:
#             if not msg.is_meta and len(msg.bytes())==3 and (msg.bytes()[0] == 144 or msg.bytes()[0] == 128):
#store the message for fast forward and backward
            midi_array.append(msg)
#initialize loop position
        max_end = len(midi_array)
        loop_start = 0
        loop_end = max_end
#play in the loop until quit flag is raised
        current_position = 0
        while quit_flag==0:
#load the current message
            try:
                msg = midi_array[current_position]
                midiout.send_message(msg.bytes())
                delay = msg.time/1000*tempo_multiplier
                time.sleep(delay)
            except:
                pass
#update the GUI
            try:
                c_Instruction = int((msg.bytes()[0] - msg.bytes()[0] % 0x10) /0x10)
                c_Note = msg.bytes()[1]
                c_Velocity = msg.bytes()[2]  
                try:
                    key_loc = WHITE_KEY.index(c_Note)
                    if c_Instruction==NOTE_ON and c_Velocity>0: #if the key is pressed, draw green color //white_key_pressed //WHITE_KEY
                        midi_white_key_pressed[key_loc] = 1
                    elif c_Instruction==NOTE_OFF or c_Velocity==0: #if the key is released, draw white color
                        midi_white_key_pressed[key_loc] = 0
                except:
                    key_loc = BLACK_KEY.index(c_Note)
                    actual_key_loc = BLACK_KEY_ARRAY_INDEX[key_loc]
                    if c_Instruction==NOTE_ON and c_Velocity>0: #if the key is pressed, draw green color //white_key_pressed //WHITE_KEY
                        midi_black_key_pressed[actual_key_loc] = 1
                    elif c_Instruction==NOTE_OFF or c_Velocity==0: #if the key is released, draw white color
                        midi_black_key_pressed[actual_key_loc] = 0
            except:
                pass

# progress to the next message
            current_position+=1
            if current_position >= max_end:
                current_position = loop_start
        
        quit_flag = 0
        is_playing_flag = 0
        clear_GUI()
        console_box.delete(1.0,END)
        console_box.insert(1.0, ("Finished!\n"))
    except:
        quit_flag = 0
        is_playing_flag = 0
        console_box.delete(1.0,END)
        console_box.insert(1.0, "Please select a file and a midi device before play!\n")
        console_box.insert(2.0, ("Current file: "+filename+"\n"))
        console_box.insert(3.0, "Current device: "+midi_device+"\n")

#refresh input device list
def refresh_input_list():
    global midiin
    global midiout
    midiin.close_port()
    midiout.close_port()
    myMenu_Input.delete(2,'end')
    port = 0;
    for device in midiin.get_ports():
        myMenu_Input.add_command(label=device, command=partial(open_port, device, port), font=menufont)
        port+=1
    device_box.delete(1.0,END)
    device_box.insert(1.0, ("Available MIDI devices updated! Select your MIDI device."))

#connect to midi device
def open_port(device, port):
    global midi_device
    global midiin
    global midiout
    midi_device = device
    midiin.close_port()
    midiout.close_port()
    midiin.open_port(port)
    midiout.open_port(port)
    listen_to_piano_thread = threading.Thread(target=listen_to_midi_input_thread)
    listen_to_piano_thread.start()
    device_box.delete(1.0,END)
    device_box.insert(1.0, (midi_device + " is connected!"))

#auto connect to the available midi device
def auto_connect():
    global midi_device
    global midiin
    global midiout
    midiin.close_port()
    midiout.close_port()
    myMenu_Input.delete(2,'end')
    port = 0;
    for device in midiin.get_ports():
        myMenu_Input.add_command(label=device, command=partial(open_port, device, port), font=menufont)
        if port==1:
            open_port(device, port)
        port+=1
    
#if the virtual piano is clicked, send the corresponding signal to the digital piano
def send_to_piano(note):
    global midiout
    try:
        msg = mido.Message.from_bytes([0x90, note, 0x60])
        midiout.send_message(msg.bytes())
    except:
        device_box.delete(1.0,END)
        device_box.insert(1.0, "No MIDI device detected! Connect and retry.")
    
#if a device is connected, this function should start as a thread to keep tracking of input message
def listen_to_midi_input_thread():
    global midiin
    global user_white_key_pressed
    global user_black_key_pressed
    global MIDI_PIANO_KEY_OFFSET
    while True:
        try:
            msg = midiin.get_message()
            if msg:
                c_Instruction = int((msg[0][0] - msg[0][0] % 0x10) /0x10)
                c_Note = msg[0][1]
                c_Velocity = msg[0][2]
#               here is the code which transfer the input to virtual piano gui:
                try:
                    key_loc = WHITE_KEY.index(c_Note)
                    if c_Instruction==NOTE_ON and c_Velocity>0: #if the key is pressed, draw green color //white_key_pressed //WHITE_KEY
                        user_white_key_pressed[key_loc] = 1
                    elif c_Instruction==NOTE_OFF or c_Velocity==0: #if the key is released, draw white color
                        user_white_key_pressed[key_loc] = 0
                except:
                    key_loc = BLACK_KEY.index(c_Note)
                    actual_key_loc = BLACK_KEY_ARRAY_INDEX[key_loc]
                    if c_Instruction==NOTE_ON and c_Velocity>0: #if the key is pressed, draw green color //white_key_pressed //WHITE_KEY
                        user_black_key_pressed[actual_key_loc] = 1
                    elif c_Instruction==NOTE_OFF or c_Velocity==0: #if the key is released, draw white color
                        user_black_key_pressed[actual_key_loc] = 0
        except:
            print("listen_to_midi_input_thread EXCEPTION")

#after finish, clear the piano GUI
def clear_GUI():
    global midi_white_key_pressed
    global midi_black_key_pressed
    for i in range (0, len(midi_white_key_pressed)):
        midi_white_key_pressed[i] = 0
    for i in range (0, len(midi_black_key_pressed)):
        midi_black_key_pressed[i] = 0 

#create a pygame virtual piano
def virtual_piano():
    global virtual_piano_screen
    global current_position
    is_running = True
    while is_running:
#constantly looking for mouse press
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                is_running = False
#if a key is pressed, make it green and send midi message to the piano
            if event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.FINGERDOWN:
                mouse_x, mouse_y = pygame.mouse.get_pos()
#if a virtual piano key is pressed
                try:
                    if mouse_y > 50 and mouse_y < 100: #white key pressed
                        white_key_num = int(mouse_x / KEY_WIDTH)
                        user_white_key_pressed[white_key_num] = 1
                        send_to_piano(WHITE_KEY[white_key_num])
                    elif mouse_y <= 50: #black key pressed
                        black_key_num = int((mouse_x-BLACK_KEY_START_OFFSET) / KEY_WIDTH)
                        user_black_key_pressed[black_key_num] = 1
                        try:
                            actual_black_key_num = BLACK_KEY_ARRAY_INDEX.index(black_key_num)
                            send_to_piano(BLACK_KEY[actual_black_key_num])
                        except:
                            pass
                    elif mouse_y > 100 and mouse_x <= 936 and mouse_x >=50:
                        current_position = map_range_to_range(mouse_x,50,936,0,max_end)
                except:
                    pass
#if mouse release, clean all the pressed keys
            if event.type == pygame.MOUSEBUTTONUP or event.type == pygame.FINGERUP:
                for i in range(0,52):
                    if user_white_key_pressed[i] == 1:
                        user_white_key_pressed[i] = 0
                for i in range(0,50):
                    if user_black_key_pressed[i] == 1:
                        user_black_key_pressed[i] = 0
                        
        virtual_piano_screen.fill(GREY)
        draw_piano()
        pygame.display.update()

#this function draw the pygame virtual piano
def draw_piano():
#     screen.blit()
    global virtual_piano_screen
    global BLACK_KEY_ARRAY_INDEX
    global user_white_key_pressed
    global midi_white_key_pressed
    global user_black_key_pressed
    global midi_black_key_pressed
    global max_end
    global current_position
    global loop_start
    global loop_end
    
#draw white keys
    for i in range (0,52):
#if the key is not pressed by any body, show white
        if midi_white_key_pressed[i] == 0 and user_white_key_pressed[i] == 0:
            pygame.draw.rect(virtual_piano_screen,WHITE,(i*KEY_WIDTH, 0, KEY_WIDTH-HORIZONTAL_GAP, WHITE_KEY_HEIGHT))
#if the user pressed the key that is shown by the midi, show green color
        elif midi_white_key_pressed[i] == 1 and user_white_key_pressed[i] == 1:
            pygame.draw.rect(virtual_piano_screen,GREEN,(i*KEY_WIDTH, 0, KEY_WIDTH-HORIZONTAL_GAP, WHITE_KEY_HEIGHT))
#if the midi press the key but the user does not, show blue color
        elif midi_white_key_pressed[i] == 1 and user_white_key_pressed[i] == 0:
            pygame.draw.rect(virtual_piano_screen,BLUE,(i*KEY_WIDTH, 0, KEY_WIDTH-HORIZONTAL_GAP, WHITE_KEY_HEIGHT))
#if the midi does not press the key but the user does, show red color
        elif midi_white_key_pressed[i] == 0 and user_white_key_pressed[i] == 1:
            pygame.draw.rect(virtual_piano_screen,RED,(i*KEY_WIDTH, 0, KEY_WIDTH-HORIZONTAL_GAP, WHITE_KEY_HEIGHT)) #(topleft_x,topleft_y,x_length,y_length)
            
#draw black keys
    for i in range (0,50):
        try:
            black_key_num = BLACK_KEY_ARRAY_INDEX.index(i)
            if black_key_num>=0:
#if the key is not pressed by any body, show white
                pygame.draw.rect(virtual_piano_screen,BLACK,(i*KEY_WIDTH+BLACK_KEY_START_OFFSET, 0, KEY_WIDTH-HORIZONTAL_GAP, BLACK_KEY_HEIGHT))
#if the user pressed the key that is shown by the midi, show green color
                if midi_black_key_pressed[i] == 1 and user_black_key_pressed[i] == 1:
                    pygame.draw.rect(virtual_piano_screen,GREEN,(i*KEY_WIDTH+BLACK_KEY_START_OFFSET+HORIZONTAL_GAP, 0, KEY_WIDTH-3*HORIZONTAL_GAP, BLACK_KEY_HEIGHT-HORIZONTAL_GAP))
#if the midi press the key but the user does not, show blue color
                elif midi_black_key_pressed[i] == 1 and user_black_key_pressed[i] == 0:
                    pygame.draw.rect(virtual_piano_screen,BLUE,(i*KEY_WIDTH+BLACK_KEY_START_OFFSET+HORIZONTAL_GAP, 0, KEY_WIDTH-3*HORIZONTAL_GAP, BLACK_KEY_HEIGHT-HORIZONTAL_GAP))
#if the midi does not press the key but the user does, show red color
                elif midi_black_key_pressed[i] == 0 and user_black_key_pressed[i] == 1:
                    pygame.draw.rect(virtual_piano_screen,RED,(i*KEY_WIDTH+BLACK_KEY_START_OFFSET+HORIZONTAL_GAP, 0, KEY_WIDTH-3*HORIZONTAL_GAP, BLACK_KEY_HEIGHT-HORIZONTAL_GAP))
        except:
            pass
        
#draw progress bar
    pygame.draw.rect(virtual_piano_screen,DARK_GREY,(50,120,886,5))
    pin_x_loc = map_range_to_range(current_position,0,max_end,50,936)
#     print(pin_x_loc)
    pygame.draw.rect(virtual_piano_screen,BLACK,(pin_x_loc,110,10,25))

#main
###############################################################################################################
#get available midi device
midiin = rtmidi.MidiIn()
midiout = rtmidi.MidiOut()
midi_device = ""
# available_ports_in = midiin.get_ports()
# available_ports_out = midiout.get_ports()
is_playing_flag = 0
filename = ''
LED_Array_Time = []
LED_Array = []
Current_Row_Playing = -1

WHITE_KEY = [21,23,
             24,26,28,
             29,31,33,35,
             36,38,40,
             41,43,45,47,
             48,50,52,
             53,55,57,59,
             60,62,64,
             65,67,69,71,
             72,74,76,
             77,79,81,83,
             84,86,88,
             89,91,93,95,
             96,98,100,
             101,103,105,107,
             108]

BLACK_KEY = [22,
             25,27,
             30,32,34,
             37,39,
             42,44,46,
             49,51,
             54,56,58,
             61,63,
             66,68,70,
             73,75,
             78,80,82,
             85,87,
             90,92,94,
             97,99,
             102,104,106]


BLACK_KEY_ARRAY_INDEX = [0,
                         2,3,
                         5,6,7,
                         9,10,
                         12,13,14,
                         16,17,
                         19,20,21,
                         23,24,
                         26,27,28,
                         30,31,
                         33,34,35,
                         37,38,
                         40,41,42,
                         44,45,
                         47,48,49]
                         
# print(available_ports)


###############################################################################################################
#create root frame
root = Tk()
root.title('Digital Piano Fingering Guide')
root.geometry("1024x260")

###############################################################################################################
#create menu and attach to the top

# select font style
menufont = tkFont.Font(size=20)
textfont = tkFont.Font(size=15)
#create menu attach to the root
myMenu = Menu(root) #create root menu attach to the root
root.config(menu=myMenu)
#create "File" menu
myMenu_File = Menu(myMenu) #create file menu attach to the root menu
myMenu.add_cascade(label=" File ", menu=myMenu_File, font=menufont)
myMenu_File.add_command(label="New...", command=command_1, font=menufont)
myMenu_File.add_command(label="Open", command=open_midi_file, font=menufont)
myMenu_File.add_separator()
myMenu_File.add_command(label="Exit", command=root.destroy, font=menufont)

#create "Input" menu. This menu will dynamically detect new input midi devices
myMenu_Input= Menu(myMenu) #create file menu attach to the root menu    
myMenu.add_cascade(label=" Input ", menu=myMenu_Input, font=menufont)
myMenu_Input.add_command(label="Refresh", command=refresh_input_list, font=menufont)
   
#create "Setting" menu
myMenu_Setting = Menu(myMenu) #create file menu attach to the root menu
myMenu.add_cascade(label=" Setting ", menu=myMenu_Setting, font=menufont)
myMenu_Setting.add_command(label="Tempo", command=command_1, font=menufont)
myMenu_Setting.add_command(label="Brightness", command=command_1, font=menufont)

###############################################################################################################
#create a device frame for connect midi device
# device_frame = Frame(root)
# device_frame.grid(row=0,column=1)
widget_frame = Frame(root)
widget_frame.grid(row=0,column=0)

device_button = Button(widget_frame, text="Connect", width=10, height=1,font=menufont, command=auto_connect)
device_button.grid(row=0,column=0)

device_box = Text(widget_frame, width=40, height=1,font=textfont)
device_box.insert(1.0, "Please connect your MIDI piano via USB cable.")
device_box.grid(row=0,column=1)

#create a text box for open file
# file_frame = Frame(root)
# file_frame.grid(row=2,column=1)

file_button = Button(widget_frame, text="File", width=10, height=1, font=menufont, command=open_midi_file)
file_button.grid(row=1,column=0)

file_box = Text(widget_frame, width=40, height=1,font=textfont)
file_box.insert(1.0, "Please select the midi file you want to play.")
file_box.grid(row=1,column=1)

#create a text box for diagnostic
console_box = Text(widget_frame, width=40, height=5, font=textfont)# width=60, height=20
console_box.grid(row=2,column=1)

#play mode selection
play_mode_frame = Frame(widget_frame)
play_mode_frame.grid(row=2,column=0)

listen_button = Button(play_mode_frame, text="Listen!", command=listen_to_midi, font=menufont, width=10, height=1,)
listen_button.grid(row=0,column=0)

play_button = Button(play_mode_frame, text="Play!", command=play_with_midi, font=menufont, width=10, height=1,)
play_button.grid(row=1,column=0)

stop_button = Button(play_mode_frame, text="Stop!", command=stop_play, font=menufont, width=10, height=1,)
stop_button.grid(row=2,column=0)
###############################################################################################################
#create virtual piano
pygame.init()
#create the screen, title and icon
virtual_piano_screen = pygame.display.set_mode((986,150))
pygame.display.set_caption('Digital Piano Fingering Guide')
my_virtual_piano = threading.Thread(target=virtual_piano)
my_virtual_piano.start()

###############################################################################################################
#run the GUI loop
root.mainloop()
